import 'package:flutter/material.dart';
import 'package:student_login/screens/forgotpassword/body.dart';
import 'package:student_login/screens/home/body.dart';
import 'package:student_login/screens/notification/Student/body.dart';
import 'package:student_login/screens/notification/staff/body.dart';

Map<String, WidgetBuilder> routes = {
  routeForgot: (context) => ForgotPassword(),
  routeHome: (context) => AdminHomePage(),
  routeStaffNotification: (context) => StaffNotificationPage(),
  routeStudentNotifiaction: (context) => StudentNotificationPage()
};

///route name constants
const String routeForgot = "/forgotPage";
const String routeHome = "/homePage";
const String routeStaffNotification = "/staffNotification";
const String routeStudentNotifiaction = "/staffNotification";
