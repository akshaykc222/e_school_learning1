import 'dart:convert';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:student_login/screens/forgotpassword/body.dart';
import 'package:student_login/screens/home/body3.dart';
import 'package:student_login/screens/login/getx/loginget.dart';
import 'package:student_login/screens/login/model/loginmodel.dart';
import 'package:student_login/utils/constants.dart';

import '../home/body.dart';

class LoginUI extends StatefulWidget {
  @override
  _LoginUIState createState() => _LoginUIState();
}

class _LoginUIState extends State<LoginUI> with SingleTickerProviderStateMixin {
  final formkey = GlobalKey<FormState>();
  final username = TextEditingController();
  final password = TextEditingController();
  bool _passwordVisible = true;

  late AnimationController _controller;
  late Animation<double> _animation;

  void checkLogin(String username, password) async {
    var headers = {'Content-Type': 'application/json'};
    var request = http.Request(
        'POST',
        Uri.parse(
            '${UIGuide.baseURL}/login?id=16f71c18-5144-42d1-bc55-edba05a6e22f'));
    request.body = json.encode({"email": username, "password": password});
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var data = jsonDecode(await response.stream.bytesToString());
      // SharedPreferences prefs = await SharedPreferences.getInstance();
      LoginModel res = LoginModel.fromJson(data);
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString("accesstoken", res.accessToken);
      print(res.accessToken);
      Provider.of<LoginProvider>(context, listen: false).getToken(context);
      var parsedResponse = await parseJWT(context);
      if (parsedResponse['role'] == "Guardian") {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => StudentHomePage()));
      } else {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const AdminHomePage()));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Invalid Username or Password")));
    }
  }

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );

    _animation = Tween<double>(begin: .7, end: 1).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.ease,
      ),
    )
      ..addListener(
        () {
          setState(() {});
        },
      )
      ..addStatusListener(
        (status) {
          if (status == AnimationStatus.completed) {
            _controller.reverse();
          } else if (status == AnimationStatus.dismissed) {
            _controller.forward();
          }
        },
      );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _inputField2(
    TextEditingController controller,
  ) {
    double _width = MediaQuery.of(context).size.width;
    return Column(
      children: [
        Container(
          height: _width / 4,
          width: _width / 1.25,
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: TextFormField(
              validator: (val) {
                if (val!.isEmpty) {
                  return "Please enter any value";
                } else if (val.length <= 8) {
                  return "enter correct password";
                }
              },
              //obscureText: true,

              controller: controller,
              obscureText: _passwordVisible,
              decoration: InputDecoration(
                  suffixIcon: IconButton(
                    icon: Icon(
                      // Based on passwordVisible state choose the icon
                      _passwordVisible
                          ? Icons.visibility
                          : Icons.visibility_off,
                      color: Colors.black54,
                    ),
                    onPressed: () {
                      // Update the state i.e. toogle the state of passwordVisible variable
                      setState(() {
                        _passwordVisible = !_passwordVisible;
                      });
                    },
                  ),
                  labelText: 'Password',
                  hintText: 'enter your password',
                  isCollapsed: false,
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: UIGuide.PRIMARY),
                    borderRadius: BorderRadius.circular(15.0),
                  )),
            ),
          ),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    double _width = MediaQuery.of(context).size.width;
    double _height = MediaQuery.of(context).size.height;
    return Scaffold(
      //backgroundColor: Color(0xff292C31),
      backgroundColor: UIGuide.offwhite,
      body: ScrollConfiguration(
        behavior: MyBehavior(),
        child: SingleChildScrollView(
          child: SizedBox(
            height: _height,
            child: Column(
              children: [
                const Expanded(child: SizedBox()),
                Expanded(
                  flex: 4,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const SizedBox(),
                      const Text(
                        'SIGN IN',
                        style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.w800,
                          //color: Color(0xffA9DED8),
                          color: UIGuide.PRIMARY,
                        ),
                      ),
                      //SizedBox(),
                      _inputField1(username),
                      _inputField2(password),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          RichText(
                            text: TextSpan(
                              text: 'Forgot password!',
                              style: const TextStyle(
                                  fontSize: 15,
                                  //color: Color(0xffA9DED8),
                                  color: UIGuide.PRIMARY),
                              recognizer: TapGestureRecognizer()
                                ..onTap = () {
                                  HapticFeedback.lightImpact();
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              ForgotPassword()));
                                },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Stack(
                    children: [
                      Center(
                        child: Container(
                          margin: EdgeInsets.only(bottom: _width * .07),
                          height: _width * .5,
                          width: _width * .5,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                Colors.transparent,
                                Color(0xff610815),
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                        ),
                      ),
                      Center(
                        child: Transform.scale(
                          scale: _animation.value,
                          child: InkWell(
                            splashColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () {
                              HapticFeedback.lightImpact();
                              checkLogin(username.text, password.text);
                            },
                            child: Container(
                              height: _width * .2,
                              width: _width * .2,
                              alignment: Alignment.center,
                              decoration: const BoxDecoration(
                                //color: Color(0xffA9DED8),
                                color: UIGuide.PRIMARY,
                                shape: BoxShape.circle,
                              ),
                              child: const Text(
                                'SIGN-IN',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(bottom: 20),
                  height: 80,
                  child: Image.asset(UIGuide.ourlogo),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _inputField1(TextEditingController controller) {
    double _width = MediaQuery.of(context).size.width;

    return Container(
      height: _width / 4,
      width: _width / 1.22,
      child: Column(
        children: [
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextFormField(
              validator: (val) {
                if (val!.isEmpty) {
                  return "Please enter any value";
                } else if (!RegExp(
                        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                    .hasMatch(val)) {
                  return "please enter a valid email";
                }
              },
              controller: controller,
              decoration: InputDecoration(
                  labelText: 'Username',
                  hintText: 'enter your name',
                  isCollapsed: false,
                  border: OutlineInputBorder(
                    borderSide: const BorderSide(color: UIGuide.PRIMARY),
                    borderRadius: BorderRadius.circular(15.0),
                  )),
            ),
          )
        ],
      ),
    );
  }
}

class MyBehavior extends ScrollBehavior {
  @override
  Widget buildViewportChrome(
      BuildContext context, Widget child, AxisDirection axisDirection) {
    return child;
  }
}
