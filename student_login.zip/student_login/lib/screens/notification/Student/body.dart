import 'dart:core';

import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:provider/provider.dart';
import 'package:student_login/screens/notification/Student/components/studentlist_item.dart';
import 'package:student_login/screens/notification/Student/provider/studentlist.dart';
import 'package:student_login/utils/constants.dart';

class StudentNotificationPage extends StatefulWidget {
  const StudentNotificationPage({Key? key}) : super(key: key);

  @override
  _StudentNotificationPageState createState() =>
      _StudentNotificationPageState();
}

class _StudentNotificationPageState extends State<StudentNotificationPage> {
  var scrollcontroller = ScrollController();

  final spinkit = const SpinKitRotatingCircle(
    color: Colors.white,
    size: 50.0,
  );

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      var p = Provider.of<StudentNotification>(context, listen: false);
      p.getStudenList(loadmore: false);
      p.clearAllFilters();
      p.getCourseList(loadmore: false);
      p.getDivisionList(loadmore: false);
    });
    scrollcontroller.addListener(() {
      if (scrollcontroller.position.pixels ==
          scrollcontroller.position.maxScrollExtent) {
        print("Loading");
        Provider.of<StudentNotification>(context, listen: false)
            .getStudenList(loadmore: true);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    bool _isChecked = false;

    return Scaffold(
      appBar: AppBar(title: const Text("Notification To Students")),
      body: Container(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.only(top: 30.0),
          child: Consumer<StudentNotification>(builder: (context, snap, child) {
            return Column(children: [
              Container(
                // color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Row(children: [
                    Expanded(
                      child: Consumer<StudentNotification>(
                          builder: (context, snapshot, child) {
                        return DropdownSearch<String>.multiSelection(
                          label: "Course",
                          mode: Mode.DIALOG,
                          popupTitle: const Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text("Select Course"),
                          ),
                          showSearchBox: true,
                          showSelectedItems: true,
                          items: snapshot.courselist
                              .map((e) => e.name)
                              .toSet()
                              .toList(),
                        );
                      }),
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Consumer<StudentNotification>(
                            builder: (context, snapshot, child) {
                          return DropdownSearch<String>.multiSelection(
                            label: "Divison",
                            mode: Mode.DIALOG,
                            popupTitle: const Text("Select Divison"),
                            showSearchBox: true,
                            onChanged: (List<String> val) {
                              snapshot.addFilters(val.first);
                            },
                            showSelectedItems: true,
                            items: snapshot.divisionlist
                                .map((e) => e.name)
                                .toSet()
                                .toList(),
                          );
                        }),
                      ),
                    ),
                    Expanded(
                        child: Padding(
                      padding: const EdgeInsets.only(left: 2),
                      child: RawMaterialButton(
                        onPressed: () async {
                          showDialog(
                              context: context,
                              builder: (context) {
                                return spinkit;
                              });
                          await Provider.of<StudentNotification>(context,
                                  listen: false)
                              .getStudenList(loadmore: false);
                          Navigator.pop(context);
                        },
                        elevation: 2.0,
                        fillColor: UIGuide.PRIMARY,
                        child: const Text(
                          "View",
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.white,
                          ),
                        ),
                        padding: const EdgeInsets.all(20.0),
                        shape: const CircleBorder(),
                      ),
                    )),
                  ]),
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.7,
                child: Consumer<StudentNotification>(
                  builder: (context, value, child) {
                    return ListView.builder(
                      controller: scrollcontroller,
                      physics: const BouncingScrollPhysics(),
                      shrinkWrap: false,
                      itemCount: value.studentlist.length == 0
                          ? 0
                          : value.studentlist.length + 1,
                      itemBuilder: (BuildContext context, int index) {
                        return value.studentlist.length == index
                            ? const Center(
                                child: CircularProgressIndicator(),
                              )
                            : StudentListItem(model: value.studentlist[index]);
                      },
                    );
                  },
                ),
              ),
              SizedBox(
                width: 300,
                height: 50,
                child: ElevatedButton(
                  child: const Text('Proceed'),
                  onPressed: () {
                    Provider.of<StudentNotification>(context, listen: false)
                        .submitStudent(context);
                  },
                  style: ElevatedButton.styleFrom(
                      primary: UIGuide.PRIMARY,
                      padding: const EdgeInsets.all(8),
                      textStyle: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.bold)),
                ),
              ),
            ]);
          }),
        ),
      ),
    );
  }
}
