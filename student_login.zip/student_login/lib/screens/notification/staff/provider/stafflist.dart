import 'dart:convert';

import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:student_login/screens/notification/messagepage.dart';
import 'package:student_login/screens/notification/staff/model/notificationmodel.dart';

class StaffNotification with ChangeNotifier {
  int pageno = 1;
  List<StaffListModel> stafflist = [];
  List<StaffListModel> selectedList = [];
  Future<bool> getStaffList({bool? loadmore}) async {
    if (loadmore == true) {
      pageno = pageno + 1;
    }

    var headers = {'Content-Type': 'application/json'};
    var request = http.Request(
        'GET',
        Uri.parse(
            'https://api.schooltestonline.xyz/mobileapp/staffs/stafflist?page=$pageno'));
    request.body = json.encode({
      "SchoolId": "16f71c18-5144-42d1-bc55-edba05a6e22f",
      "AcademicyearId": "3ea749f3-b05b-47af-a4f6-5626df9ad6bb"
    });
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      Map<String, dynamic> data =
          jsonDecode(await response.stream.bytesToString());

      List<StaffListModel> templist = List<StaffListModel>.from(
          data["staffs"].map((x) => StaffListModel.fromJson(x)));
      stafflist.addAll(templist);

      notifyListeners();
    } else {
      print(response.reasonPhrase);
    }

    return true;
  }

  bool isSelected(StaffListModel model) {
    StaffListModel selected =
        stafflist.firstWhere((element) => element.staffId == model.staffId);
    return selected.selected ??= false;
  }

  void selectItem(StaffListModel model) {
    StaffListModel selected =
        stafflist.firstWhere((element) => element.staffId == model.staffId);

    if (selected.selected == null) {
      selected.selected = true;
    } else {
      selected.selected = !selected.selected!;
    }
    StaffListModel? selectedListItem = selectedList
        .firstWhereOrNull((element) => element.staffId == model.staffId);

    if (selectedListItem == null) {
      selectedList.add(model);
      print("adding to selected list");
    }

    notifyListeners();
  }

  submit(
    BuildContext context,
  ) {
    List<StaffListModel> tempList = [];
    tempList.addAll(selectedList);
    print(tempList.length);
    selectedList.clear();
    if (tempList.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Please select ...')));
    } else {
      print('v ${tempList.map((e) => e.staffId).toList().length}');
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => MessagePage(
                    toList: tempList.map((e) => e.staffId).toList(),
                    type: "Staff",
                  )));
    }
  }
}
