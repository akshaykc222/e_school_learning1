// class UserModel {
//   final String? name, imgUrl;

//   UserModel({
//     this.name,
//     this.imgUrl,
//   });
// }

// List<UserModel> dummyData = [
//   new UserModel(
//     name: "Stuart",
//     imgUrl: "https://m.cricbuzz.com/a/img/v1/192x192/i1/c170661/virat-kohli.jpg",
//   ),
//   new UserModel(
//     name: "Harry",
//     imgUrl: "https://m.cricbuzz.com/a/img/v1/192x192/i1/c170661/virat-kohli.jpg",
//   ),
//   new UserModel(
//     name: "Miles",
//     imgUrl: "https://m.cricbuzz.com/a/img/v1/192x192/i1/c170661/virat-kohli.jpg",
//   ),
//   new UserModel(
//     name: "Shawn",
//     imgUrl: "https://m.cricbuzz.com/a/img/v1/192x192/i1/c170661/virat-kohli.jpg",
//   ),
//   new UserModel(
//     name: "Brock",
//     imgUrl: "https://m.cricbuzz.com/a/img/v1/192x192/i1/c170661/virat-kohli.jpg",
//   ),
  
// ];
